 <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <!-- User Profile-->
                        <li class="nav-small-cap"><i class="mdi mdi-dots-horizontal"></i> <span class="hide-menu">Personal</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link" href="dashboard.php" aria-expanded="false"><i class="icon-Car-Wheel"></i><span class="hide-menu">Dashboard </span></a>
                        </li>
                        <li class="nav-small-cap"><i class="mdi mdi-dots-horizontal"></i> <span class="hide-menu">Products</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link two-column has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="icon-Box-withFolders"></i><span class="hide-menu">Products </span></a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item"><a href="searchproducts.php" class="sidebar-link"><i class="mdi mdi-email"></i><span class="hide-menu"> Search Product </span></a></li>
                                <?php
                                    if($_SESSION["useraccess"]!= 5 && $_SESSION["useraccess"]!= 4){
                                ?>
                                
                                <li class="sidebar-item"><a href="addproducts.php" class="sidebar-link"><i class="mdi mdi-email-alert"></i><span class="hide-menu"> Add Products </span></a></li>
                                <li class="sidebar-item"><a href="approvedproducts.php" class="sidebar-link"><i class="mdi mdi-email-secure"></i><span class="hide-menu"> Approved products </span></a></li>
                                <li class="sidebar-item"><a href="pendingproducts.php" class="sidebar-link"><i class="mdi mdi-book-multiple"></i><span class="hide-menu"> Pending Products </span></a></li>
                                <li class="sidebar-item"><a href="rejectedproducts.php" class="sidebar-link"><i class="mdi mdi-book-plus"></i><span class="hide-menu"> Reject Products </span></a></li>
                                <?php
                                }
                                ?>
                                </ul>
                        </li>
                        <li class="nav-small-cap"><i class="mdi mdi-dots-horizontal"></i> <span class="hide-menu">Certification Authority</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="icon-Duplicate-Window"></i><span class="hide-menu">Certification Authority </span></a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item"><a href="viewcert.php" class="sidebar-link"><i class="mdi mdi-toggle-switch"></i><span class="hide-menu"> View Certification Authority</span></a></li>
                                <?php
                                    if($_SESSION["useraccess"]!= 5 && $_SESSION["useraccess"]!= 4 && $_SESSION["useraccess"]!= 3 && $_SESSION["useraccess"]!= 2){
                                ?>
                                <li class="sidebar-item"><a href="addcert.php" class="sidebar-link"><i class="mdi mdi-tablet"></i><span class="hide-menu"> Add Certification Authority</span></a></li>
                                <?php
                                }
                                ?>
                                </ul>
                                
                        </li>
                        
                        <li class="nav-small-cap"><i class="mdi mdi-dots-horizontal"></i> <span class="hide-menu">Brands</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link two-column has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="icon-File-HorizontalText"></i><span class="hide-menu">Brands</span></a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item"><a href="searchbrands.php" class="sidebar-link"><i class="mdi mdi-email"></i><span class="hide-menu"> Search Brands</span></a></li>
                                <?php
                                    if($_SESSION["useraccess"]!= 5 && $_SESSION["useraccess"]!= 4 && $_SESSION["useraccess"]!= 2){
                                ?>
                                <li class="sidebar-item"><a href="addbrand.php" class="sidebar-link"><i class="mdi mdi-email-alert"></i><span class="hide-menu"> Add Brand</span></a></li>
                                <li class="sidebar-item"><a href="approvedbrands.php" class="sidebar-link"><i class="mdi mdi-email-secure"></i><span class="hide-menu"> Approved Brands</span></a></li>
                                <li class="sidebar-item"><a href="brandrequest.php" class="sidebar-link"><i class="mdi mdi-book-multiple"></i><span class="hide-menu"> Brand Request Pending </span></a></li>
                                <li class="sidebar-item"><a href="rejectedbrands.php" class="sidebar-link"><i class="mdi mdi-book-plus"></i><span class="hide-menu"> Rejected Brands </span></a></li>
                                <?php
                                }
                                ?>
                                
                                </ul>
                        </li>
                        
                        <li class="nav-small-cap"><i class="mdi mdi-dots-horizontal"></i> <span class="hide-menu">Ulema</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="icon-Navigation-LeftWindow"></i><span class="hide-menu">Ulema</span></a>
                            <ul aria-expanded="false" class="collapse first-level">
                                 <?php
                                    if($_SESSION["useraccess"]!= 5 && $_SESSION["useraccess"]!= 4 && $_SESSION["useraccess"]!= 2){
                                ?>
                                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="addulema.php" aria-expanded="false"><i class="mdi mdi-border-top"></i><span class="hide-menu">Add Ulema</span></a></li>
                                <?php 
                                    }
                                ?>
                                <?php
                                    if($_SESSION["useraccess"]!= 5){
                                ?>
                                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="ulemabrand.php" aria-expanded="false"><i class="mdi mdi-border-style"></i><span class="hide-menu">Ulema & Brands</span></a></li>
                                
                                <?php 
                                    }
                                ?>
                                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="searchulema.php" aria-expanded="false"><i class="mdi mdi-border-style"></i><span class="hide-menu">Search Ulema</span></a></li>
                                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="ulemalist.php" aria-expanded="false"><i class="mdi mdi-tab-unselected"></i><span class="hide-menu">Ulema List</span></a></li>
                                 
                            </ul>
                        </li>
                        <li class="nav-small-cap"><i class="mdi mdi-dots-horizontal"></i> <span class="hide-menu">Fatwas</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark sidebar-link" href="javascript:void(0)" aria-expanded="false"><i class="icon-Neutron"></i><span class="hide-menu"> Fatwas</span></a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="searchfatwa.php" aria-expanded="false"><i class="mdi mdi-image-filter-tilt-shift"></i><span class="hide-menu"> Search Fatwa</span></a></li>
                                <?php
                                    if($_SESSION["useraccess"]!= 5 && $_SESSION["useraccess"]!= 2){
                                ?>
                                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="addfatwa.php" aria-expanded="false"><i class="mdi mdi-svg"></i><span class="hide-menu"> Add Fatawa</span></a></li>
                                <?php
                                    }
                                ?>
                                <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="fatwalist.php" aria-expanded="false"><i class="mdi mdi-chart-histogram"></i><span class="hide-menu"> Fatawa List</span></a></li>
                                <li class="sidebar-item"><a href="javascript:void(0)" class="sidebar-link"><i class="mdi mdi-octagram"></i><span class="hide-menu"> Forum</span></a></li>
                                </ul>
                        </li>
                        <li class="nav-small-cap"><i class="mdi mdi-dots-horizontal"></i> <span class="hide-menu">Reports</span></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="icon-File-Hide"></i><span class="hide-menu">Report </span></a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item"><a href="authentication-login1.html" class="sidebar-link"><i class="mdi mdi-account-key"></i><span class="hide-menu"> Brand Reports </span></a></li>
                                <li class="sidebar-item"><a href="starter-kit.html" class="sidebar-link"><i class="mdi mdi-crop-free"></i> <span class="hide-menu"> Certification Authority Report</span></a></li>
                                <li class="sidebar-item"><a href="pages-animation.html" class="sidebar-link"><i class="mdi mdi-debug-step-over"></i> <span class="hide-menu"> Product Report</span></a></li>
                                <li class="sidebar-item"><a href="pages-search-result.html" class="sidebar-link"><i class="mdi mdi-search-web"></i> <span class="hide-menu"> Ulema Report</span></a></li>
                            <?php
                                    if($_SESSION["useraccess"]!= 5){
                                ?>
                                <li class="sidebar-item"><a href="authentication-login2.html" class="sidebar-link"><i class="mdi mdi-account-key"></i><span class="hide-menu"> Users Review Report</span></a></li>
                            <?php
                                    }
                            ?>
                            </ul>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="icon-File-Hide"></i><span class="hide-menu">E-Code </span></a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item"><a href="halal-Ecodes.php" class="sidebar-link"><i class="mdi mdi-account-key"></i><span class="hide-menu"> Halal E-codes </span></a></li>
                                <li class="sidebar-item"><a href="haram-Ecodes.php" class="sidebar-link"><i class="mdi mdi-crop-free"></i> <span class="hide-menu"> Haram E-codes</span></a></li>
                                <?php
                                    if($_SESSION["useraccess"]!= 5&&$_SESSION["useraccess"]!= 2&&$_SESSION["useraccess"]!= 4){
                                ?>
                                <li class="sidebar-item"><a href="add-ecodes.php" class="sidebar-link"><i class="mdi mdi-octagram"></i><span class="hide-menu"> Add E-codes</span></a></li>
                                <?php 
                                    }
                                ?>

                            </ul>
                        </li>
                        <?php
                                    if($_SESSION["useraccess"]== 1){
                                ?>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="icon-Increase-Inedit"></i><span class="hide-menu">Users</span></a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item"><a href="javascript:void(0)" class="sidebar-link"><i class="mdi mdi-octagram"></i><span class="hide-menu"> Add Users</span></a>
                                    <ul aria-expanded="false" class="collapse second-level">
                                        <li class="sidebar-item"><a href="addauthorityuser.php" class="sidebar-link"><i class="mdi mdi-priority-low"></i><span class="hide-menu"> Add Authority Users</span></a></li>
                                        <li class="sidebar-item"><a href="addbranduser.php" class="sidebar-link"><i class="mdi mdi-rounded-corner"></i><span class="hide-menu"> Add Brand Users</span></a></li>
                                        <li class="sidebar-item"><a href="addulemauser.php" class="sidebar-link"><i class="mdi mdi-select-all"></i><span class="hide-menu"> Add Ulema User</span></a></li>
                                        </ul>                                
                                </li>
                                
                                <li class="sidebar-item"><a href="viewusers.php" class="sidebar-link"><i class="mdi mdi-octagram"></i><span class="hide-menu"> View Users</span></a></li></ul>
                                <?php 
                                    }
                                ?>
                                </ul>
                        </li>
                        

                        
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
       