 <footer class="footer text-center">
                All Rights Reserved by Halal o Product Verifier Project of Hamdard Univeristy, Karachi Pakistan.<br/> 
                Designed and Developed by Anas ur Rasheed, Asher Bin Naseem & Muhammad Umer.<br/>
                Supervised by Prof. Doc. Adnan Ahmed Siddiqui & Assistant Prof. Afzal Hussain.
                
            </footer>