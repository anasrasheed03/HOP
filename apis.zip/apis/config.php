<?php
 
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "maknam_anas");
define("DB_PASSWORD", "Racespeed@#!@");
define("DB_DATABASE", "maknam_halal_product");
?>