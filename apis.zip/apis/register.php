<?php
 
require_once 'DB_Functions.php';
$db = new DB_Functions();
 
// json response array
$response = array("error" => FALSE);
 
if (isset($_POST['loginid']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['pictures'])) {
 
    // receiving the post params
    $loginid = $_POST['loginid'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $pictures = $_POST['pictures'];
 $activationcode=md5($email.time());
    // check if user is already existed with the same email
    if ($db->isUserExisted($email)) {
        // user already existed
        $response["error"] = TRUE;
        $response["error_msg"] = "User already existed with " . $email;
        echo json_encode($response);
    } else {
        // create a new user
        $user = $db->storeUser($loginid, $email, $password, $pictures,$activationcode);
        if ($user) {
            // user stored successfully
            $response["error"] = FALSE;
            $response["user"]["loginid"] = $user["loginid"];
            echo json_encode($response);
        } else {
            // user failed to store
            $response["error"] = TRUE;
            $response["error_msg"] = "Unknown error occurred in registration!";
            echo json_encode($response);
        }
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (name, email or password) is missing!";
    echo json_encode($response);
}
?>